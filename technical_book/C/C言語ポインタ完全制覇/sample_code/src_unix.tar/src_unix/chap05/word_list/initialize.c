#include "word_manage_p.h"

Word *word_header = NULL;

/************************************************************
 * 単語管理部を初期化する
 ************************************************************/
void word_initialize(void)
{
    word_header = NULL;
}

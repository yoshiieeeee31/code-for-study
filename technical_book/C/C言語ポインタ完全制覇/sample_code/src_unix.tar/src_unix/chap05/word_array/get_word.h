#ifndef GET_WORD_H_INCLUDED
#define GET_WORD_H_INCLUDED
#include <stdio.h>

int get_word(char *buf, int size, FILE *stream);

#endif /* GET_WORD_H_INCLUDED */
